from __future__ import annotations

import json
import tempfile
import unittest
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

import torch

from paper.aaai27.experiments.aggregate_human_review import summarize_prompt_majorities
from paper.aaai27.experiments.compile_vbench_paired_statistics import per_video_values
from paper.aaai27.experiments.collect_results import inspect_factorial_config
from paper.aaai27.experiments.prepare_blind_review import comparison_pairs, review_paths
from paper.aaai27.experiments.run_final_quality_efficiency import build_cases as build_efficiency_cases
from paper.aaai27.experiments.run_final_quality_efficiency import build_analysis_pairs
from paper.aaai27.experiments.run_final_quality_efficiency import write_config as write_efficiency_config
from paper.aaai27.experiments.run_step40_strength_factorial import build_cases as build_strength_cases
from changing_resolution.ralu_nt_math import ralu_resume_parameters, ralu_stage_sigmas
from changing_resolution.ralu_wan_state import (
    _expand_parent_patches,
    _independent_transition_noise,
    first_ralu_handoff,
    patchify_wan_latent,
    scatter_wan_patches,
    second_ralu_handoff,
)
from wan_sr.schedulers.ralu_nt import exact_grouped_projection_noise


class Step40StrengthSuiteTest(unittest.TestCase):
    def test_names_every_strength_and_exposes_custom_review_pairs(self) -> None:
        cases = build_strength_cases(40, [0.5, 0.75, 1.0])
        self.assertEqual(len(cases), 8)
        self.assertIn("step40_lora_s0p75_stage2", {case.name for case in cases})
        manifest = {
            "review_pairs": [
                {
                    "comparison": "lora_s0p75_with_stage2",
                    "step": 40,
                    "left_case": "step40_base_stage2",
                    "right_case": "step40_lora_s0p75_stage2",
                }
            ]
        }
        self.assertEqual(
            comparison_pairs(40, manifest),
            [("lora_s0p75_with_stage2", "step40_base_stage2", "step40_lora_s0p75_stage2")],
        )


class HumanPromptStatisticsTest(unittest.TestCase):
    def test_prompt_majority_sign_test_and_fleiss_kappa(self) -> None:
        prompt_votes = {
            ("lora", "temporal_stability", "0"): Counter({"base": 3}),
            ("lora", "temporal_stability", "1"): Counter({"lora": 2, "base": 1}),
            ("lora", "temporal_stability", "2"): Counter({"tie": 2, "lora": 1}),
        }
        rows, agreement = summarize_prompt_majorities(prompt_votes, {"lora": {"base", "lora"}})
        by_case = {row["preferred_case"]: row for row in rows}
        self.assertEqual(by_case["base"]["prompt_majorities"], 1)
        self.assertEqual(by_case["lora"]["prompt_majorities"], 1)
        self.assertEqual(by_case["tie"]["prompt_majorities"], 1)
        self.assertEqual(by_case["base"]["two_sided_sign_test_p"], 1.0)
        self.assertEqual(agreement[0]["ratings_per_item"], 3)
        self.assertIsInstance(agreement[0]["fleiss_kappa"], float)

    def test_named_review_paths_do_not_overwrite_default_package(self) -> None:
        root = Path("root")
        default = review_paths(root, "default")
        step45 = review_paths(root, "step45")
        self.assertNotEqual(default, step45)
        self.assertEqual(step45[0], root / "review/step45")


class FinalQualityEfficiencySuiteTest(unittest.TestCase):
    def test_final_wan50_strength_defaults_are_aligned(self) -> None:
        experiments = Path(__file__).resolve().parents[1]
        manifest = json.loads(
            (experiments / "experiment_manifest.json").read_text(encoding="utf-8")
        )
        defaults = manifest["defaults"]
        self.assertEqual(defaults["WAN50_LORA40_STRENGTH_FINAL"], "0.75")
        self.assertEqual(defaults["WAN50_LORA45_STRENGTH_FINAL"], "0.75")

        wan50 = next(task for task in manifest["tasks"] if task["id"] == "wan50_factorial")
        command = wan50["commands"][0]
        self.assertIn("40=${WAN50_LORA40_STRENGTH_FINAL}", command)
        self.assertNotIn("40=1.0", command)

    def test_protocol_contains_unified_pareto_sweeps(self) -> None:
        args = SimpleNamespace(step40_strength=0.75, step45_strength=0.75)
        cases = {case.name: case for case in build_efficiency_cases(args)}
        self.assertEqual(len(cases), 11)
        self.assertEqual(cases["full_hr50"].total_evaluations, 50)
        self.assertEqual(cases["lightx2v_cr48"].hr_evaluations, 2)
        self.assertEqual(cases["talh40"].hr_evaluations, 10)
        self.assertEqual(cases["talh45"].hr_evaluations, 5)
        self.assertEqual(cases["full_lr50_stage2_1hr"].lr_evaluations, 50)
        self.assertEqual(cases["full_lr50_stage2_1hr"].total_evaluations, 51)
        self.assertEqual(cases["full_lr50_stage2_5hr"].total_evaluations, 55)
        self.assertEqual(cases["ralu_quality"].lr_evaluations, 5)
        self.assertEqual(cases["ralu_quality"].mixed_evaluations, 6)
        self.assertEqual(cases["ralu_quality"].hr_evaluations, 7)
        self.assertEqual(cases["ralu_quality"].total_evaluations, 18)
        self.assertEqual(
            cases["ralu_quality"].reschedule_mode,
            "ralu_three_stage_ntdm_region_adaptive",
        )

        pairs = build_analysis_pairs(list(cases.values()))
        pair_names = {pair["comparison"] for pair in pairs}
        self.assertIn("lightx2v_cr40_vs_talh40", pair_names)
        self.assertIn("ralu_quality_vs_lightx2v_cr45", pair_names)
        self.assertIn("ralu_quality_vs_talh45", pair_names)
        self.assertIn("full_lr50_stage2_2hr_vs_full_lr50_stage2_5hr", pair_names)

    def test_writes_full_lr_refinement_and_full_hr_configs(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            args = SimpleNamespace(
                step40_strength=0.75,
                step45_strength=0.75,
                num_frames=81,
                guide_scale=6.0,
                stage2_checkpoint=str(root / "stage2.pt"),
                stage2_train_config=str(root / "stage2.yaml"),
                stage2_use_ema=False,
                final_refine_shift_increment=1.0,
                lora40_checkpoint=str(root / "lora40.safetensors"),
                lora45_checkpoint=str(root / "lora45.safetensors"),
            )
            for artifact in (
                args.stage2_checkpoint,
                args.stage2_train_config,
                args.lora40_checkpoint,
                args.lora45_checkpoint,
            ):
                Path(artifact).touch()
            cases = {case.name: case for case in build_efficiency_cases(args)}
            full_hr_path = root / "full_hr.json"
            full_lr_path = root / "full_lr.json"
            lightx2v_path = root / "lightx2v.json"
            ralu_path = root / "ralu.json"
            write_efficiency_config(full_hr_path, args, cases["full_hr50"])
            write_efficiency_config(full_lr_path, args, cases["full_lr50_stage2_1hr"])
            write_efficiency_config(lightx2v_path, args, cases["lightx2v_cr40"])
            write_efficiency_config(ralu_path, args, cases["ralu_quality"])
            full_hr = json.loads(full_hr_path.read_text(encoding="utf-8"))
            full_lr = json.loads(full_lr_path.read_text(encoding="utf-8"))
            lightx2v = json.loads(lightx2v_path.read_text(encoding="utf-8"))
            ralu = json.loads(ralu_path.read_text(encoding="utf-8"))
            self.assertNotIn("changing_resolution", full_hr)
            self.assertEqual(full_lr["changing_resolution_steps"], [50])
            self.assertEqual(full_lr["wan_final_refine_steps"], 1)
            self.assertEqual(full_lr["wan_final_refine_shift_increment"], 1.0)
            self.assertNotIn("wan_clean_resizer_ckpt", lightx2v)
            self.assertNotIn("changing_resolution", ralu)
            self.assertEqual(ralu["infer_steps"], 18)
            self.assertEqual(ralu["wan_ralu_stage_steps"], [5, 6, 7])
            self.assertEqual(ralu["wan_ralu_end_times"], [0.3, 0.45, 1.0])
            self.assertEqual(ralu["wan_ralu_z"], 100.0)
            self.assertEqual(ralu["wan_ralu_low_latent_size"], [46, 80])
            self.assertEqual(ralu["wan_ralu_aligned_latent_size"], [92, 160])
            self.assertEqual(ralu["wan_ralu_output_latent_size"], [90, 156])
            self.assertEqual(
                ralu["wan_ralu_mixed_position_ids"],
                "official_coarse_integer_children_half_offset",
            )
            self.assertEqual(
                ralu["wan_ralu_transition_noise"],
                "official_unit_for_unchanged_and_I_minus_c11T_for_expanded",
            )
            self.assertEqual(
                ralu["wan_ralu_adaptation"],
                "full_three_stage_region_adaptive_ntdm",
            )
            full_hr_issues, _ = inspect_factorial_config(full_hr_path, asdict(cases["full_hr50"]))
            full_lr_issues, _ = inspect_factorial_config(
                full_lr_path, asdict(cases["full_lr50_stage2_1hr"])
            )
            lightx2v_issues, _ = inspect_factorial_config(
                lightx2v_path, asdict(cases["lightx2v_cr40"])
            )
            ralu_issues, _ = inspect_factorial_config(ralu_path, asdict(cases["ralu_quality"]))
            self.assertEqual(full_hr_issues, [])
            self.assertEqual(full_lr_issues, [])
            self.assertEqual(lightx2v_issues, [])
            self.assertEqual(ralu_issues, [])
            for case in cases.values():
                config_path = root / f"{case.name}.json"
                write_efficiency_config(config_path, args, case)
                issues, _ = inspect_factorial_config(config_path, asdict(case))
                self.assertEqual(issues, [], case.name)


class RALUNTMatchingTest(unittest.TestCase):
    def test_quality_resume_coefficients_and_stage_schedule(self) -> None:
        resume, upsample_weight, noise_weight = ralu_resume_parameters(0.3, 100.0)
        self.assertAlmostEqual(resume, 0.3 / 70.3)
        self.assertAlmostEqual(noise_weight, 1.0 - resume)
        self.assertAlmostEqual(upsample_weight, 1.0 / 70.3)

        stage = ralu_stage_sigmas(
            start_data_time=resume,
            end_data_time=0.45,
            num_steps=6,
            shift=8.8787,
        )
        self.assertEqual(len(stage), 7)
        self.assertAlmostEqual(stage[0], 1.0 - resume)
        self.assertAlmostEqual(stage[-1], 0.55)
        self.assertTrue(all(left > right for left, right in zip(stage, stage[1:])))

    def test_exact_projection_noise_matches_block_covariance(self) -> None:
        generator = torch.Generator().manual_seed(123)
        reference = torch.empty(100_000, 4, 1)
        noise = exact_grouped_projection_noise(
            reference,
            covariance_scale=0.025,
            generator=generator,
        ).squeeze(-1)
        covariance = torch.cov(noise.T)
        self.assertTrue(torch.allclose(covariance.diag(), torch.full((4,), 0.975), atol=0.012))
        off_diagonal = covariance[~torch.eye(4, dtype=torch.bool)]
        self.assertAlmostEqual(float(off_diagonal.mean()), -0.025, delta=0.006)
        identity_noise = exact_grouped_projection_noise(
            torch.empty(100_000, 1, 1),
            group_size=1,
            covariance_scale=0.025,
            generator=generator,
        )
        self.assertAlmostEqual(float(identity_noise.var()), 0.975, delta=0.012)

    def test_official_unchanged_token_noise_is_unit_gaussian(self) -> None:
        noise = _independent_transition_noise(
            torch.empty(100_000, 1),
            generator=torch.Generator().manual_seed(321),
        )
        self.assertAlmostEqual(float(noise.mean()), 0.0, delta=0.012)
        self.assertAlmostEqual(float(noise.var()), 1.0, delta=0.012)

    def test_wan_raw_patch_roundtrip_and_official_token_replication(self) -> None:
        latent = torch.arange(2 * 3 * 4 * 6, dtype=torch.float32).reshape(2, 3, 4, 6)
        patches = patchify_wan_latent(latent)
        indices = torch.arange(patches.shape[0])
        restored = scatter_wan_patches(
            patches,
            indices,
            channels=2,
            frames=3,
            grid=(2, 3),
        )
        self.assertTrue(torch.equal(restored, latent))

        parent = patches[[0]]
        children, child_indices, child_coords = _expand_parent_patches(
            parent,
            torch.tensor([0]),
            coarse_grid=(2, 3),
            fine_grid=(4, 6),
        )
        self.assertTrue(torch.equal(children, parent.expand(4, -1)))
        self.assertEqual(child_indices.tolist(), [0, 1, 6, 7])
        self.assertEqual(child_coords.tolist(), [[0.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0], [0.0, 1.0, 1.0]])

    def test_custom_runner_preserves_lightx2v_inference_dtype_contract(self) -> None:
        source = (
            Path(__file__).resolve().parents[4]
            / "changing_resolution/ralu_wan_quality.py"
        ).read_text(encoding="utf-8")
        self.assertIn("latents = latents.to(GET_DTYPE())", source)
        self.assertIn("state.values = state.values.to(GET_DTYPE())", source)

    def test_geometry_a_mixed_tokens_cover_aligned_grid_before_crop(self) -> None:
        latent = torch.arange(16, dtype=torch.float32).reshape(1, 1, 4, 4)
        mask = torch.tensor([[True, False], [False, False]])
        generator = torch.Generator().manual_seed(7)
        state = first_ralu_handoff(
            latent,
            mask,
            end_data_time=0.3,
            z_value=100.0,
            generator=generator,
        )
        self.assertEqual(state.coarse_count, 3)
        self.assertEqual(state.values.shape, (7, 4))
        self.assertEqual(state.fine_indices.unique().numel(), 4)
        self.assertTrue(torch.all(state.coords[:, 1:] >= 0))
        self.assertTrue(torch.all(state.coords[:, 1:] <= 1.5))
        self.assertTrue(torch.all(state.coords[: state.coarse_count, 1:].remainder(1) == 0.0))
        fine_coords = state.coords[state.coarse_count :, 1:]
        self.assertTrue(torch.all((fine_coords * 2).remainder(1) == 0.0))
        self.assertTrue(torch.any(fine_coords.remainder(1) == 0.5))

        output = second_ralu_handoff(
            state,
            end_data_time=0.45,
            z_value=100.0,
            generator=generator,
            output_latent_size=(6, 6),
        )
        self.assertEqual(output.shape, (1, 1, 6, 6))


class VBenchPairedStatisticsTest(unittest.TestCase):
    def test_extracts_per_video_values_and_normalizes_imaging_quality(self) -> None:
        payload = {
            "cases": {
                "case": {
                    "numeric_metrics": {
                        "result.imaging_quality.1.0.video_results": 75.0,
                        "result.imaging_quality.1.1.video_results": 50.0,
                    }
                }
            }
        }
        self.assertEqual(per_video_values(payload, "case", "imaging_quality"), {0: 0.75, 1: 0.5})


if __name__ == "__main__":
    unittest.main()
